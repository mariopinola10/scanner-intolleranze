#!/usr/bin/env python3
"""Pulisce i CSV estratti dall'app Monash e li integra in fodmap.json.
Uso: python3 importa_monash.py fodmap.json CSV [CSV...] [-o fodmap.json] [--scarti scarti.csv]
- corregge i valori letti male dall'OCR ("759" = "75g", "29" = "2g", "1550" = "155g") usando l'ordine verde < giallo < rosso
- scarta i nomi illeggibili (finiscono in scarti.csv da controllare a mano)
- unisce i doppioni tra categorie
- collega le voci alle voci generiche della tabella (es. "Pomodoro, comune, al naturale" -> "Pomodoro")
  e aggiunge termini da ingrediente per le voci semplici, così valgono anche per i prodotti scansionati
- marca i prodotti di marca (Schär, Kellogg's...) per il riconoscimento del prodotto scansionato"""
import argparse, csv, difflib, json, os, re, sys, unicodedata
from collections import Counter, defaultdict

CAT_MAP = {
    "frutta": "Frutta", "verdure": "Verdura", "cerealipanerisopasta": "Cereali",
    "legumi, tofu, noci": "Legumi", "latticini,senza soia e senza lattosio": "Latticini",
    "carne,pesce,uova": "Proteine", "bevande": "Bevande", "condimenti": "Condimenti",
    "grassi e oli": "Grassi e oli", "dolciumi e zuccheri": "Dolcificanti", "snack,barrette e cookie": "Snack",
    "integratori alimentari": "Integratori", "pasti certificati a basso contento di fodmap": "Piatti pronti",
    "alimenti certificati a basso contenuto di fodmap": "Prodotti certificati",
}
CAT_DEBOLI = {"nuovi alimenti", "italia", "unione europea"}          # liste trasversali: la categoria vera viene da un'altra lista
CAT_MARCA = {"Prodotti certificati", "Piatti pronti", "Integratori"}

def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")

def chiave(nome):
    return re.sub(r"[^a-z0-9]", "", norm(re.sub(r"\s*\(var\. \d+\)$", "", nome)))

# ---------- valori ----------
def num(x):
    x = (x or "").strip().replace(",", ".")
    try: return float(x)
    except ValueError: return None

def candidati(x):
    c = [x]
    s = str(int(x)) if x == int(x) else None
    if s and len(s) >= 2 and s.endswith("9"): c.append(int(s[:-1]))       # "75g" letto "759"
    if s and x >= 1000: c.append(int(s[:-1]))                            # "155g" letto "1550"
    return list(dict.fromkeys(c))

def correggi(vals):
    """vals = [verde, giallo, rosso] (None se assente). Ritorna (valori, corretti?, dubbio?)."""
    pres = [i for i, v in enumerate(vals) if v is not None]
    if not pres: return vals, False, True
    if len(pres) == 1:
        i = pres[0]; v = vals[i]; c = candidati(v)
        if len(c) > 1 and (v < 100 or v >= 1000):                          # "29" -> 2 g: scelta prudente (soglia più bassa)
            out = list(vals); out[i] = c[1]; return out, True, True
        return vals, False, False
    import itertools
    best = None
    for combo in itertools.product(*[candidati(vals[i]) for i in pres]):
        if all(combo[k] < combo[k + 1] for k in range(len(combo) - 1)):
            cambi = sum(a != b for a, b in zip(combo, [vals[i] for i in pres])) + sum(10 for c in combo if c >= 1000)
            if best is None or cambi < best[0]: best = (cambi, combo)
    if best is None: return vals, False, True
    out = list(vals)
    for i, v in zip(pres, best[1]): out[i] = v
    cambiato = any(out[i] != vals[i] for i in pres)
    return out, cambiato, cambiato or best[0] >= 10

def fmt(v):
    return "" if v is None else (str(int(v)) if v == int(v) else str(v))

# ---------- nomi ----------
def ripulisci_nome(n):
    n = n.replace("”", '"').replace("“", '"').replace('""', '"')
    n = re.sub(r'"+', "", n)
    n = re.sub(r"\b([a-zà-ù])([A-ZÀ-Ù])([a-zà-ù]+)", lambda m: m.group(2) + m.group(3) if m.group(1) == m.group(2).lower() else m.group(0), n)  # mMarmellata
    n = re.sub(r"\bal al\b", "al", n)
    n = re.sub(r"^(?:[A-Za-z]\s+)+(?=[A-Z][a-z])", "", n)                  # "G g Spezie, ..." -> "Spezie, ..."
    n = re.sub(r"\s+,", ",", re.sub(r"\s+", " ", n)).strip(" ,_;]")
    n = re.sub(r",\s*,", ",", n)
    return n[:1].upper() + n[1:]

def parole(n): return [w for w in re.findall(r"[a-zà-ù]+", norm(n)) if len(w) >= 3]

# ---------- termini da ingrediente ----------
CONTENITORI = {"spezie", "spezia", "piante aromatiche", "pianta aromatica", "erba aromatica", "frutta secca", "bacca",
               "formaggio", "prodotto spalmabile", "spalmabile", "noci", "semi"}
DI = {"farina", "fiocchi", "succo", "latte", "crusca", "fecola", "sciroppo", "miele", "pasta", "gallette", "olio", "burro"}
AGG = {"aceto", "riso", "tè", "te", "cioccolato", "cavolo", "lenticchie", "fagioli", "peperoni", "cipolla", "lattuga",
       "pomodoro", "zucca", "funghi", "fungo", "yogurt", "quinoa", "mela", "pera", "uva", "banana", "kiwi", "melone",
       "patata", "cetriolo", "spinaci", "olive", "mais", "avena", "zucchero", "vino", "alghe", "piselli", "peperoncino", "cereali"}
QUALIF = re.compile(r"^(al naturale|comune|bianc[oaie]|vaccino|mucca|intero|tutti i tagli, al naturale|naturale|crud[oaie]|cott[oaie]|fresc[oaie]|fresche|essiccat[oaie]|scolat[oaie]|sbucciat[oaie]|non sbucciat[oaie]|"
                    r"denocciolat[oaie]|sgusciat[oaie]|interi?|intere|macinat[oaie]|in polvere|polvere|congelat[oaie]|bollit[oaie]|"
                    r"senza semi|a contenuto di grassi normale|matur[oaie]|sod[oaie]|biologic[oaie]|in scatola.*|sott.aceto.*|tutti i tagli|tutte le varietà)$")

def termini_ingrediente(nome):
    seg = [s.strip() for s in nome.lower().split(",") if s.strip()]
    if not seg: return []
    out = []
    def alternative(s): return [x.strip() for x in s.split("/") if x.strip()]
    testa = seg[0]
    sec = next((s for s in seg[1:] if not QUALIF.match(s)), None)
    if testa == "formaggio" and sec and sec.startswith(("panna", "crema")):
        return ["formaggio spalmabile", "formaggio cremoso"]
    if testa in CONTENITORI:
        if sec:
            for x in alternative(sec):
                if x in ("semi", "foglie", "fiori", "radice", "polvere", "bacche", "frutti", "foglia"): continue
                out.append(("semi di " + x) if testa == "semi" and not x.startswith("semi") else x)
    else:
        for t in alternative(testa):
            if not (t in DI and sec): out.append(t)
            if sec and not re.search(r"\(|contiene|senza|%", sec):
                for x in alternative(sec):
                    if x.startswith(("di ", "d'", "d’")): out.append(f"{t} {x}")
                    elif t in DI: out.append(f"{t} di {x}")
                    elif t in AGG: out.append(f"{t} {x}")
    pul = []
    for t in out:
        t = re.sub(r"\s+", " ", re.sub(r"\(.*?\)", "", t)).strip(" .")
        if 3 <= len(t) <= 40 and not re.search(r"\d|®|™", t) and t not in pul: pul.append(t)
    return pul

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tabella"); ap.add_argument("csv", nargs="+")
    ap.add_argument("-o", default=None); ap.add_argument("--scarti", default="scarti_monash.csv")
    a = ap.parse_args()
    import glob                                                     # Windows non espande *.csv
    a.csv = sorted({f for x in a.csv for f in (glob.glob(x) if any(c in x for c in "*?") else [x])})
    if not a.csv: sys.exit("Nessun CSV trovato.")
    DB = json.load(open(a.tabella, encoding="utf-8"))

    righe = []
    for f in a.csv:
        with open(f, encoding="utf-8-sig", newline="") as fh:
            for r in csv.DictReader(fh, delimiter=";"):
                if not (r.get("nome") or "").strip(): continue
                r["_cat"] = (r.get("categoria") or "").strip().lower()
                righe.append(r)

    # vocabolario per riconoscere i nomi illeggibili
    voc = Counter()
    for r in righe: voc.update(set(parole(ripulisci_nome(r["nome"]))))
    for x in DB["alimenti"]:
        for t in [x["nome"], *x.get("termini", [])]: voc.update({w: 2 for w in parole(t)})
    def parola_ok(t):
        t = re.sub(r"[^A-Za-zÀ-ÿ]", "", t)
        if not t: return True                                  # numeri, simboli, "100%"
        if len(t) == 1: return t in "aeoNS"
        return bool(re.fullmatch(r"[a-zà-ÿ]+|[A-ZÀ-Ý][a-zà-ÿ]+|[A-ZÀ-Ý]{2,}[a-z]?|(?:[A-ZÀ-Ý][a-zà-ÿ]+)+[A-ZÀ-Ý]?|[A-Z][a-z][A-Z]", t))
    def leggibilita(n):
        tok = [t for t in re.split(r"[\s,;()/]+", n) if t]
        if not tok or len(re.sub(r"[^A-Za-zÀ-ÿ]", "", n)) < 3: return 0
        return sum(1 for t in tok if parola_ok(t)) / len(tok)

    voci, scarti = [], []
    for r in righe:
        nome = ripulisci_nome(r["nome"])
        vals = [num(r.get(k)) for k in ("verde", "giallo", "rosso")]
        vals = [None if v is not None and v <= 0 else v for v in vals]
        orig = list(vals)
        vals, corr, dubbio = correggi(vals)
        leg = leggibilita(nome)
        if not corr and vals[0] is not None and vals[0] in (19, 29, 39) and (vals[1] is not None or vals[2] is not None):
            dubbio = True; corr = False
            r["note"] = f"Verde letto {int(vals[0])}: potrebbe essere {int(vals[0]) // 10} g (lettura dallo schermo), controlla nell'app."
        rec = {"nome": nome, "cat": r["_cat"], "vals": vals, "unita": (r.get("unita") or "g").strip() or "g",
               "dubbio": dubbio or (r.get("conferma") or "").strip() == "da verificare", "corr": corr, "leg": leg,
               "nota_ocr": (r.get("note") or "").strip(), "orig": orig}
        if leg < .75 or not any(v is not None for v in vals): scarti.append(rec); continue
        voci.append(rec)

    # categoria: quella "vera" vince sulle liste trasversali
    cat_di = {}
    for v in voci:
        k = chiave(v["nome"])
        if v["cat"] not in CAT_DEBOLI: cat_di.setdefault(k, CAT_MAP.get(v["cat"], v["cat"].capitalize()))
    # marche: ultimo segmento dei nomi nelle liste di prodotti
    marche = Counter()
    for v in voci:
        cat = cat_di.get(chiave(v["nome"])) or ""
        if cat in CAT_MARCA or v["cat"] in CAT_DEBOLI or re.search(r"®|™", v["nome"]):
            seg = [s.strip() for s in v["nome"].split(",")]
            if len(seg) >= 2: marche[seg[-1]] += 1
    marche = {m for m, c in marche.items() if c >= 1 and re.search(r"[A-Z]", m) and len(m) <= 30 and not QUALIF.match(m.lower())
              and m.lower() not in {"al naturale", "cotto", "cotta", "crudo", "essiccato"}}

    # doppioni: stesso nome e stessi valori -> una voce; stesso nome e valori diversi -> varianti
    uniche = {}
    for v in voci:
        k = chiave(v["nome"]) + "|" + "|".join(fmt(x) for x in v["vals"])
        if k in uniche:
            u = uniche[k]
            if v["leg"] > u["leg"]: v["dubbio"] = v["dubbio"] and u["dubbio"]; uniche[k] = v
            else: u["dubbio"] = u["dubbio"] and v["dubbio"]
        else: uniche[k] = v
    voci = list(uniche.values())
    # quasi-doppioni con stessi valori (nome letto male in una copia)
    per_val = defaultdict(list)
    for v in voci: per_val[tuple(v["vals"])].append(v)
    tieni = []
    for gruppo in per_val.values():
        gruppo.sort(key=lambda v: -v["leg"])
        scelti = []
        for v in gruppo:
            n = chiave(v["nome"])
            if any(abs(len(n) - len(chiave(x["nome"]))) <= 4 and difflib.SequenceMatcher(None, n, chiave(x["nome"])).ratio() > .88
                   for x in scelti): continue
            scelti.append(v)
        tieni += scelti
    voci = tieni

    # nomi uguali con valori diversi -> (var. 2)
    base_nomi = Counter()
    voci.sort(key=lambda v: (chiave(v["nome"]), v["dubbio"]))
    for v in voci:
        b = re.sub(r"\s*\(var\. \d+\)$", "", v["nome"])
        base_nomi[chiave(b)] += 1
        n = base_nomi[chiave(b)]
        v["nome"] = b if n == 1 else f"{b} (var. {n})"

    # ---------- integrazione ----------
    vecchie_monash = [x for x in DB["alimenti"] if x.get("monash")]          # import precedenti: si aggiornano, non si duplicano
    DB["alimenti"] = [x for x in DB["alimenti"] if not x.get("monash")]
    esistenti = {chiave(x["nome"]): x for x in DB["alimenti"]}
    def re_termini(lista):
        parti = [r"(?<![\w])" + re.escape(t.rstrip("*")).replace(r"\ ", r"[\s-]+") + ("" if t.endswith("*") else r"(?![\w])") for t in lista if t]
        return re.compile("|".join(parti), re.I) if parti else None
    generiche = [(x, re_termini(x.get("termini", []))) for x in DB["alimenti"]]
    def generica_per(termine):
        best = None
        for x, rx in generiche:
            if not rx: continue
            m = rx.fullmatch(termine) or rx.search(termine)
            if m and (m.group(0) == termine or len(m.group(0)) >= len(termine) - 2):
                if best is None or len(m.group(0)) > best[1]: best = (x, len(m.group(0)))
        return best[0] if best else None

    nuove, rappr = [], defaultdict(list)
    collegati = defaultdict(list)
    for v in voci:
        cat = cat_di.get(chiave(v["nome"])) or ("Prodotti certificati" if v["cat"] in CAT_DEBOLI and any(m in v["nome"] for m in marche) else
                                                 CAT_MAP.get(v["cat"], "Nuovi alimenti" if v["cat"] == "nuovi alimenti" else "Altro"))
        if cat == "Legumi" and re.match(r"(frutta secca|semi|noci|noce|mix di semi)", v["nome"].lower()): cat = "Frutta a guscio e semi"
        if cat == "Legumi" and re.match(r"(tofu|tempeh|alternative alla carne|carne macinata|pellicola|sostituto)", v["nome"].lower()): cat = "Proteine"
        seg = [s.strip() for s in v["nome"].split(",")]
        marca = seg[-1] if len(seg) >= 2 and seg[-1] in marche else ""
        pz = {k: x for k, x in zip(("verde", "giallo", "rosso"), v["vals"]) if x is not None}
        pz["unita"] = "ml" if v["unita"].lower().startswith("m") else "g"
        note = []
        if v["corr"]: note.append("Lettura dallo schermo corretta in automatico (letto " + " / ".join(fmt(x) for x in v["orig"] if x is not None) + "): controlla nell'app.")
        elif v["nota_ocr"].startswith("Verde letto"): note.append(v["nota_ocr"])
        elif v["dubbio"]: note.append("Lettura dallo schermo incerta: controlla i valori nell'app.")
        rec = {"nome": v["nome"], "categoria": cat, "termini": [], "escludi": [], "en": [], "concentrato": False, "livelli": {},
               "porzione": "", "note": " ".join(note), "fonti": ["MONAPP"], "conferma": "da verificare" if v["dubbio"] else "confermato",
               "porzioni": pz}
        if marca: rec["marca"] = marca
        k = chiave(v["nome"])
        if k in esistenti:                                         # stessa voce già in tabella: aggiorno le soglie
            x = esistenti[k]; x["porzioni"] = pz
            if "MONAPP" not in x.get("fonti", []): x.setdefault("fonti", []).append("MONAPP")
            continue
        nuove.append(rec)
        if marca or cat in ("Piatti pronti", "Integratori"): continue
        for t in termini_ingrediente(re.sub(r"\s*\(var\. \d+\)$", "", v["nome"])):
            g = generica_per(t)
            if g is not None:
                collegati[g["nome"]].append((rec, t))
            else:
                rappr[t].append(rec)

    def punteggio(r):
        n = r["nome"].lower()
        s = 0
        if re.search(r"al naturale|crud|comune|fresc", n): s += 3
        if re.search(r"essiccat(?!.*boll)|in scatola|sott.aceto|congelat|salamoia|polvere|\(var\.", n): s -= 3
        if "solo foglie" in n: s -= 2
        if "solo bulbo" in n or "solo teste" in n: s += 1
        s += sum(1 for k in ("verde", "giallo", "rosso") if k in r["porzioni"])
        s -= n.count(",")
        return s
    # termini nuovi: vanno alla variante più "base"
    for t, lista in rappr.items():
        r = max(lista, key=punteggio)
        if t not in r["termini"]: r["termini"].append(t)
    # voci generiche collegate: elenco varianti + soglie della variante base se mancano
    gen_by = {x["nome"]: x for x in DB["alimenti"]}
    def radici(t): return {w[:-1] if len(w) > 4 else w for w in re.findall(r"[a-z]+", norm(t)) if w not in ("di", "e", "d", "al", "la", "il")}
    def solo_testa(r):
        """vero se il nome è 'Testa, qualificatori' (es. 'Kiwi, crudo', 'Pomodoro, comune, al naturale')"""
        seg = [s.strip().lower() for s in re.sub(r"\s*\(var\. \d+\)$", "", r["nome"]).split(",")]
        if seg[0] in CONTENITORI: seg = seg[1:]
        return len(seg) >= 1 and all(QUALIF.match(s) for s in seg[1:])
    for nome_g, lista in collegati.items():
        g = gen_by[nome_g]
        viste = []
        for r, t in lista:
            if r["nome"] not in viste: viste.append(r["nome"])
        g["varianti"] = sorted(set(g.get("varianti", [])) | set(viste))
        if "," in g["nome"]: continue                                   # voce che raggruppa più alimenti: niente soglie uniche
        primo = re.split(r"\s+e\s+", g["nome"])[0]
        cand = [r for r, t in lista if solo_testa(r) and radici(t) <= radici(primo)]
        if not cand: continue
        fresco = g.get("categoria") in ("Frutta", "Verdura")
        cand = [r for r in cand if r["conferma"] == "confermato" and (not re.search(
                ("essiccat|" if fresco else "") + r"polvere|sott.aceto|congelat|salamoia", r["nome"].lower())
                or re.search(r"essiccat|secc|polvere|sott.aceto|congelat|salamoia", g["nome"].lower()))]
        if not cand: continue
        base = max(cand, key=punteggio)
        if not g.get("porzioni") and base["conferma"] == "confermato":
            g["porzioni"] = dict(base["porzioni"]); g["porzioni_da"] = base["nome"]
            if "MONAPP" not in g.get("fonti", []): g.setdefault("fonti", []).append("MONAPP")

    for r in nuove: r["monash"] = True
    chiavi_nuove = {chiave(r["nome"]) for r in nuove}
    tenute = [x for x in vecchie_monash if chiave(x["nome"]) not in chiavi_nuove]   # categorie non reimportate restano
    DB["alimenti"] += nuove + tenute
    DB["alimenti"].sort(key=lambda x: (x["categoria"], norm(x["nome"])))
    DB["versione"] = DB.get("versione", 1) + 1
    DB["fonti"]["MONAPP"] = {"nome": "Monash University FODMAP Diet app (dati letti dall'app, uso personale autorizzato)", "url": ""}
    out = a.o or a.tabella
    al = DB.pop("alimenti")
    testo = json.dumps(DB, ensure_ascii=False, indent=1)[:-2] + ',\n "alimenti": [\n' + \
        ",\n".join("  " + json.dumps(x, ensure_ascii=False, separators=(",", ":")) for x in al) + "\n ]\n}\n"
    DB["alimenti"] = al
    open(out, "w", encoding="utf-8").write(testo)

    with open(a.scarti, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh, delimiter=";"); w.writerow(["nome letto", "categoria", "verde", "giallo", "rosso", "unita", "motivo"])
        for s in scarti:
            w.writerow([s["nome"], s["cat"], *[fmt(x) for x in s["vals"]], s["unita"], "nome illeggibile" if s["leg"] < .75 else "nessun valore"])

    dub = sum(1 for r in nuove if r["conferma"] != "confermato")
    print(f"Righe lette: {len(righe)} | voci Monash nuove: {len(nuove)} (da verificare: {dub}) | scartate: {len(scarti)}")
    print(f"Voci generiche collegate a varianti Monash: {len(collegati)} | termini da ingrediente aggiunti: {sum(len(r['termini']) for r in nuove)}")
    print(f"Marche riconosciute: {len(marche)} | totale voci in tabella: {len(DB['alimenti'])}")

if __name__ == "__main__":
    main()
