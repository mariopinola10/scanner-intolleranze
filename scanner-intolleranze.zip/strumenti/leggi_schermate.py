#!/usr/bin/env python3
"""Legge screenshot o una registrazione schermo dell'app (liste con soglie colorate) e scrive un CSV
importabile in tabella.html. Uso: python3 leggi_schermate.py INPUT [INPUT...] -o monash.csv
INPUT = immagini (png/jpg) e/o video (mp4/webm/mov). Le soglie sono assegnate dal COLORE del pallino."""
import argparse, colorsys, csv, os, re, subprocess, sys, tempfile, glob
from PIL import Image
import pytesseract, shutil

# Windows: trova tesseract nel percorso standard dell'installer
if not shutil.which("tesseract"):
    for p in (r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
        if os.path.exists(p): pytesseract.pytesseract.tesseract_cmd = p; break

VAL = re.compile(r"^(\d+(?:[.,]\d+)?)\s?(g|ml)$", re.I)

def colore(rgb):
    r, g, b = [x / 255 for x in rgb]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    h *= 360
    if s < .45 or v < .45: return None
    if h < 18 or h > 340: return "rosso"
    if 25 <= h <= 55: return "giallo"
    if 90 <= h <= 170: return "verde"
    return None

def campiona(im, cx, cy, r=8):
    px = [im.getpixel((x, y)) for x in range(max(0, cx - r), min(im.width, cx + r)) for y in range(max(0, cy - r), min(im.height, cy + r))]
    if not px: return None
    px.sort(key=lambda p: sum(p))
    return colore(px[len(px) // 2])

def leggi_valore(crop):
    """Separa le cifre dall'unità (g / ml) guardando la forma dei caratteri, poi legge solo le cifre."""
    import numpy as np
    from scipy import ndimage
    a = np.asarray(crop.convert("L")).astype(float) / 255
    lab, n = ndimage.label(a < .5)
    comp = [(sl[1].start, sl[1].stop, sl[0].start, sl[0].stop) for sl in ndimage.find_objects(lab)]
    comp = [c for c in comp if (c[3] - c[2]) > a.shape[0] * .2]
    if not comp: return None
    comp.sort()
    # unisci pezzi sovrapposti in orizzontale (es. punti)
    glifi = []
    for c in comp:
        if glifi and c[0] < glifi[-1][1] - 1:
            g = glifi[-1]; glifi[-1] = (min(g[0], c[0]), max(g[1], c[1]), min(g[2], c[2]), max(g[3], c[3]))
        else: glifi.append(c)
    # tronca al primo spazio largo (fine del valore)
    alt = np.median([g[3] - g[2] for g in glifi])
    for i in range(1, len(glifi)):
        if glifi[i][0] - glifi[i - 1][1] > alt * .6: glifi = glifi[:i]; break
    base = np.median([g[3] for g in glifi])
    unita, cifre = "g", glifi
    last = glifi[-1]
    if last[3] > base + alt * .15 and len(glifi) > 1:          # 'g' scende sotto la riga
        cifre = glifi[:-1]
    elif len(glifi) > 2 and (glifi[-2][1] - glifi[-2][0]) > alt * .8 and (last[1] - last[0]) < alt * .35:
        unita, cifre = "ml", glifi[:-2]                         # 'm' larga + 'l' stretta
    if not cifre: return None
    x0, x1 = max(0, cifre[0][0] - 3), cifre[-1][1] + 3
    sub = crop.crop((x0, 0, x1, crop.height))
    t = pytesseract.image_to_string(sub, lang="eng", config="--psm 7 -c tessedit_char_whitelist=0123456789.,").strip().replace(" ", "")
    m = re.fullmatch(r"(\d+(?:[.,]\d+)?)", t)
    return (float(m.group(1).replace(",", ".")), unita) if m else None

def righe_frame(path, lang):
    import numpy as np
    from scipy import ndimage
    im = Image.open(path).convert("RGB"); W, H = im.size
    arr = np.asarray(im).astype(float) / 255
    mx, mn = arr.max(2), arr.min(2)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    forte = (sat > .55) & (mx > .55)
    cls = np.zeros((H, W), dtype=np.uint8)  # 1 rosso 2 giallo 3 verde
    cls[forte & (r > .7) & (g < .35) & (b < .45)] = 1
    cls[forte & (r > .85) & (g > .55) & (g < .8) & (b < .3)] = 2
    cls[forte & (g > .55) & (r < .35) & (b < .5)] = 3
    nomi = {1: "rosso", 2: "giallo", 3: "verde"}
    dots, big = [], []
    for k in (1, 2, 3):
        lab, n = ndimage.label(cls == k)
        for i, sl in enumerate(ndimage.find_objects(lab), 1):
            h = sl[0].stop - sl[0].start; w = sl[1].stop - sl[1].start
            area = (lab[sl] == i).sum()
            if abs(h - w) > .2 * max(h, w) or area < .6 * h * w * .7: continue
            cx = (sl[1].start + sl[1].stop) // 2; cy = (sl[0].start + sl[0].stop) // 2
            if .88 * W <= cx and h > 60: big.append((cy, nomi[k]))
            elif .17 * W <= sl[1].start < .75 * W and .025 * W <= h <= .06 * W: dots.append((cy, sl[1].start, sl[1].stop, nomi[k], h))
    dots.sort()
    gruppi = []
    for d in dots:
        if gruppi and abs(gruppi[-1][0][0] - d[0]) < 18: gruppi[-1].append(d)
        else: gruppi.append([d])
    # inizio/fine area bianca della lista (salta barra del titolo e barra in basso)
    col = arr[:, int(.6 * W)]
    bianco = col.min(1) > .9
    top = 0
    while top < H // 3 and not bianco[top]: top += 1
    bot = H - 1
    while bot > H * 2 // 3 and not bianco[bot]: bot -= 1
    lum = arr.mean(2)
    ox = int(.175 * W)   # OCR solo sulla colonna del testo (evita fusioni con foto e pallino a destra)
    d = pytesseract.image_to_data(im.crop((ox, 0, int(.86 * W), H)), lang=lang, config="--psm 6", output_type=pytesseract.Output.DICT)
    d["left"] = [x + ox for x in d["left"]]
    parole = []
    for i in range(len(d["text"])):
        t = d["text"][i].strip(); x, y, w, h = d["left"][i], d["top"][i], d["width"][i], d["height"][i]
        conf = int(float(d["conf"][i]))
        if not t or (conf < 40 and len(t) <= 3) or not (.17 * W <= x < .86 * W) or not re.search(r"[\w/]", t): continue
        if y < top + 4 or y + h > bot - 2: continue
        if lum[y:y + h, x:x + w].min() > .2: continue
        if sat[y:y + h, x:x + w].mean() > .25: continue          # bandierine e icone colorate          # testo grigio (marca) o su fondo colorato
        if re.fullmatch(r"\d+[g9mlI]*", t): continue             # valori letti come testo
        parole.append((x, y + h / 2, t, y))
    out, prec = [], 0
    for gr in gruppi:
        gr.sort(key=lambda x: x[1]); cy = int(sum(x[0] for x in gr) / len(gr)); h = gr[0][4]
        soglie, ok = {}, True
        for j, (_, x0, x1, col, hh) in enumerate(gr):
            fine = gr[j + 1][1] - 6 if j + 1 < len(gr) else min(W, x1 + 230)
            crop = im.crop((x1 + 4, cy - int(h * .9), fine, cy + int(h * .9)))
            v = leggi_valore(crop)
            if not v: ok = False; continue
            soglie.setdefault(col, []).append(v)
        if cy - h < top + 4 or cy + h > bot: prec = cy + h / 2; continue   # riga tagliata dal bordo
        titolo = sorted((p for p in parole if prec - 2 < p[1] < cy - h / 2), key=lambda p: p[1])
        if titolo and titolo[0][3] < top + 6: prec = cy + h / 2; continue  # titolo tagliato in alto
        righe_t, cur = [], []
        for p in titolo:
            if cur and p[1] - cur[-1][1] > 22: righe_t.append(cur); cur = []
            cur.append(p)
        if cur: righe_t.append(cur)
        nome = " ".join(p[2] for rt in righe_t for p in sorted(rt, key=lambda p: p[0]))
        glob_c = next((c for (y, c) in big if abs(y - (cy - 50)) < 90), None)
        if nome: out.append({"nome": nome, "soglie": soglie, "ok": ok, "globale": glob_c})
        prec = cy + h / 2
    return out

def estrai_frame(video, cartella, fps):
    subprocess.run(["ffmpeg", "-loglevel", "error", "-i", video, "-vf", f"fps={fps}", os.path.join(cartella, os.path.basename(video) + "_%05d.png")], check=True)
    return sorted(glob.glob(os.path.join(cartella, os.path.basename(video) + "_*.png")))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", nargs="+"); ap.add_argument("-o", default="monash.csv")
    ap.add_argument("--fps", type=float, default=2); ap.add_argument("--lang", default="ita")
    ap.add_argument("--categoria", default="Altro")
    a = ap.parse_args()
    tmp = tempfile.mkdtemp(); frames = []
    if a.lang not in pytesseract.get_languages(config=""):
        print(f"Lingua '{a.lang}' non installata in Tesseract: uso 'eng'"); a.lang = "eng"
    espansi = []
    for p in a.input:
        if os.path.isdir(p):
            espansi += sorted(glob.glob(os.path.join(p, "*.png")) + glob.glob(os.path.join(p, "*.jpg")) + glob.glob(os.path.join(p, "*.jpeg")))
        else: espansi.append(p)
    for i, p in enumerate(espansi):
        frames += estrai_frame(p, tmp, a.fps) if p.lower().endswith((".mp4", ".webm", ".mov", ".mkv")) else [p]
    visti = {}
    norm = lambda t: re.sub(r"[^a-z0-9]", "", t.lower())
    tot = len(frames)
    for k, f in enumerate(frames, 1):
        pct = k * 100 // tot
        barra = "#" * (pct // 4) + "-" * (25 - pct // 4)
        print(f"\rLettura immagini [{barra}] {pct:3d}%  ({k}/{tot})", end="", flush=True)
        for r in righe_frame(f, a.lang):
            chiave = tuple(sorted((c, v[0]) for c, vs in r["soglie"].items() for v in vs))
            lista = visti.setdefault(chiave, [])
            n = norm(r["nome"])
            for j, e in enumerate(lista):
                m = norm(e["nome"])
                import difflib
                if n == m or n.endswith(m) or m.endswith(n) or (abs(len(n) - len(m)) <= 2 and difflib.SequenceMatcher(None, n, m).ratio() > .9):
                    if len(n) > len(m): lista[j] = r
                    break
            else: lista.append(r)
    print()
    visti = {i: r for i, r in enumerate(x for l in visti.values() for x in l)}
    nomi = {}
    cols = ["nome","categoria","termini","escludi","fruttosio","lattosio","sorbitolo","mannitolo","fruttani","gos","verde","giallo","rosso","unita",
            "g100_fruttosio","g100_lattosio","g100_sorbitolo","g100_mannitolo","g100_fruttani","g100_gos","concentrato","porzione","note","fonti","conferma"]
    righe, dubbi = [], 0
    for r in visti.values():
        nome = re.sub(r"\s+", " ", r["nome"]).strip(" ,")
        nome = " ".join(w.capitalize() if w.isupper() and len(w.strip(",.")) > 2 else w for w in nome.split())
        if not nome[:1].isupper(): r["ok"] = False   # inizio del nome probabilmente tagliato
        nomi[nome] = nomi.get(nome, 0) + 1
        if nomi[nome] > 1: nome += f" (var. {nomi[nome]})"
        s = r["soglie"]; unita = {u for vs in s.values() for _, u in vs}
        dup = any(len(v) > 1 for v in s.values()) or not r["ok"]
        row = dict.fromkeys(cols, "")
        row.update(nome=nome, categoria=a.categoria, termini=nome.lower(), unita=(unita.pop() if len(unita) == 1 else "g"),
                   concentrato="no", fonti="MONAPP", conferma="da verificare" if dup else "confermato",
                   note=("Soglie lette dallo schermo, controllare: " + "; ".join(f"{c} {v[0]}{v[1]}" for c, vs in s.items() for v in vs)) if dup else "")
        for c in ("verde", "giallo", "rosso"):
            if c in s: row[c] = str(s[c][0][0]).rstrip("0").rstrip(".") if "." in str(s[c][0][0]) else str(int(s[c][0][0]))
        dubbi += dup; righe.append(row)
    righe.sort(key=lambda x: x["nome"].lower())
    with open(a.o, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, delimiter=";"); w.writeheader(); w.writerows(righe)
    print(f"{len(righe)} alimenti letti da {len(frames)} schermate, {dubbi} da controllare -> {a.o}")

if __name__ == "__main__":
    main()
