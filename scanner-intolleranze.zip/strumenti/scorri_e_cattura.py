#!/usr/bin/env python3
"""Scorre una lista aperta sul telefono (via ADB) e salva uno screenshot a ogni passo.
Prerequisiti: Opzioni sviluppatore > Debug USB attivo, telefono collegato, `adb` installato sul PC.
Uso: python3 scorri_e_cattura.py nome-lista [--max 400] [--pausa 0.9]
Prima di lanciarlo apri nell'app la lista da leggere (cima della lista). Si ferma da solo a fine lista."""
import argparse, hashlib, os, re, subprocess, sys, time

def adb(*a, out=False):
    r = subprocess.run(["adb", *a], capture_output=True)
    if r.returncode: sys.exit("Errore adb: " + r.stderr.decode(errors="ignore") + "\nTelefono collegato e debug USB autorizzato?")
    return r.stdout if out else None

ap = argparse.ArgumentParser()
ap.add_argument("nome"); ap.add_argument("--max", type=int, default=400)
ap.add_argument("--pausa", type=float, default=0.9); ap.add_argument("--durata", type=int, default=700)
a = ap.parse_args()
m = re.search(rb"(\d+)x(\d+)", adb("shell", "wm", "size", out=True))
w, h = int(m.group(1)), int(m.group(2))
x, y0, y1 = w // 2, int(h * .78), int(h * .32)   # scorre ~46% dello schermo: le righe si sovrappongono tra uno scatto e l'altro
os.makedirs(a.nome, exist_ok=True)
prec, uguali = None, 0
for i in range(a.max):
    png = adb("exec-out", "screencap", "-p", out=True)
    if len(png) < 20000:
        sys.exit("Schermata nera o vuota: l'app potrebbe bloccare gli screenshot. In quel caso fermati qui.")
    hsh = hashlib.md5(png).hexdigest()
    uguali = uguali + 1 if hsh == prec else 0
    if uguali >= 1: print("Fine lista."); break
    prec = hsh
    open(os.path.join(a.nome, f"{a.nome}_{i:04d}.png"), "wb").write(png)
    adb("shell", "input", "swipe", str(x), str(y0), str(x), str(y1), str(a.durata))
    time.sleep(a.pausa)
print(f"Salvati {i} screenshot in ./{a.nome}/")
