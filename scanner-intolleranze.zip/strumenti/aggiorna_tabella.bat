@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if not exist fodmap.json (
  echo Copia qui fodmap.json scaricato dal tuo repository GitHub, poi rilancia.
  pause
  exit /b 1
)
echo Integro tutti i CSV di questa cartella e della cartella csv in fodmap.json...
python importa_monash.py fodmap.json "*.csv" "csv\*.csv" --scarti scarti_monash.csv
if errorlevel 1 (echo Errore durante l'import.) else (echo Fatto: carica fodmap.json su GitHub. Le righe illeggibili sono in scarti_monash.csv.)
pause
