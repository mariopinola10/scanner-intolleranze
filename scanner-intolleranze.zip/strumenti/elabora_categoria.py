#!/usr/bin/env python3
"""Chiede la categoria, legge gli screenshot dalla cartella fissa e crea <categoria>.csv
lanciando leggi_schermate.py. Alla fine sposta gli screenshot in archivio\\<categoria>
così la cartella è pronta per la categoria successiva."""
import os, re, shutil, subprocess, sys, glob

QUI = os.path.dirname(os.path.abspath(__file__))
# Cartella fissa dove metti gli screenshot (cambiala qui se vuoi un percorso diverso)
INPUT = os.path.join(QUI, "screenshot")
OUTPUT = os.path.join(QUI, "csv")
ARCHIVIO = os.path.join(QUI, "archivio")
LETTORE = os.path.join(QUI, "leggi_schermate.py")

def immagini():
    return sorted(f for e in ("*.png", "*.jpg", "*.jpeg") for f in glob.glob(os.path.join(INPUT, e)))

def main():
    for d in (INPUT, OUTPUT, ARCHIVIO): os.makedirs(d, exist_ok=True)
    if not os.path.exists(LETTORE):
        sys.exit(f"Non trovo {LETTORE}: metti questo file nella stessa cartella di leggi_schermate.py")
    while True:
        print(f"\nCartella screenshot: {INPUT}")
        foto = immagini()
        print(f"Immagini presenti: {len(foto)}")
        categoria = input("Categoria da elaborare (invio vuoto per uscire): ").strip()
        if not categoria: break
        if not foto:
            print("Nessuna immagine nella cartella screenshot. Copiale lì e riprova."); continue
        nome_file = re.sub(r"[^\w\-]+", "_", categoria).strip("_") or "categoria"
        csv_out = os.path.join(OUTPUT, nome_file + ".csv")
        r = subprocess.run([sys.executable, LETTORE, INPUT, "-o", csv_out, "--categoria", categoria])
        if r.returncode:
            print("Errore durante la lettura: gli screenshot restano dove sono."); continue
        print(f"CSV creato: {csv_out}")
        if input("Sposto gli screenshot in archivio per la prossima categoria? [S/n] ").strip().lower() in ("", "s", "si", "sì", "y"):
            dest = os.path.join(ARCHIVIO, nome_file)
            os.makedirs(dest, exist_ok=True)
            for f in foto: shutil.move(f, os.path.join(dest, os.path.basename(f)))
            print(f"Spostati {len(foto)} file in {dest}")
    print("Fine.")

if __name__ == "__main__":
    main()
