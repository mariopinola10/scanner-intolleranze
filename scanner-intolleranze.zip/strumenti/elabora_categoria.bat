@echo off
cd /d "%~dp0"
python elabora_categoria.py
pause
