@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

:inizio
echo.
set "CAT="
set /p "CAT=Categoria da elaborare (es. frutta, invio vuoto per uscire): "
if "%CAT%"=="" goto fine

echo.
echo Apri nell'app la lista "%CAT%" dall'inizio, poi premi un tasto per partire.
pause >nul

echo.
echo === 1/2 Cattura screenshot in "%CAT%" ===
python scorri_e_cattura.py "%CAT%"
if errorlevel 1 (
  echo Errore nella cattura: controlla che il telefono sia collegato ^(adb devices^).
  goto inizio
)

echo.
echo === 2/2 Lettura screenshot e creazione "%CAT%.csv" ===
python leggi_schermate.py "%CAT%" -o "%CAT%.csv" --categoria "%CAT%"
if errorlevel 1 (
  echo Errore nella lettura degli screenshot.
  goto inizio
)

echo.
echo Fatto: %CAT%.csv
goto inizio

:fine
echo Fine.
pause
